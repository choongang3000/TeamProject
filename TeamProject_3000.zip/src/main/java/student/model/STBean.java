package student.model;

public class STBean {

}
