package student.model;

public class STUOrderBindBean {
	private STUOrderBean obean;
	private String coname;
	private int elseNum;
	public STUOrderBean getObean() {
		return obean;
	}
	public void setObean(STUOrderBean obean) {
		this.obean = obean;
	}
	public String getConame() {
		return coname;
	}
	public void setConame(String coname) {
		this.coname = coname;
	}
	public int getElseNum() {
		return elseNum;
	}
	public void setElseNum(int elseNum) {
		this.elseNum = elseNum;
	}
	
}
