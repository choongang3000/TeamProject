package teachers.model;

public class TEBean {
	private int tnum;
	private String tid;
	private String tname;
	private String t_image;
	private String subject;
	private String visa;
	private String tterm;
	private String twageratio;
	private String introduction;
	
	private int conum;
	private String coname;
	private String coteacher;
	private String cosubject;
	private String coimage;
	private String covideo;
	private String cocontent;
	private String coprice;
	private String coupload_date;
	
	
	public int getConum() {
		return conum;
	}
	public void setConum(int conum) {
		this.conum = conum;
	}
	public String getConame() {
		return coname;
	}
	public void setConame(String coname) {
		this.coname = coname;
	}
	public String getCoteacher() {
		return coteacher;
	}
	public void setCoteacher(String coteacher) {
		this.coteacher = coteacher;
	}
	public String getCosubject() {
		return cosubject;
	}
	public void setCosubject(String cosubject) {
		this.cosubject = cosubject;
	}
	public String getCoimage() {
		return coimage;
	}
	public void setCoimage(String coimage) {
		this.coimage = coimage;
	}
	public String getCovideo() {
		return covideo;
	}
	public void setCovideo(String covideo) {
		this.covideo = covideo;
	}
	public String getCocontent() {
		return cocontent;
	}
	public void setCocontent(String cocontent) {
		this.cocontent = cocontent;
	}
	public String getCoprice() {
		return coprice;
	}
	public void setCoprice(String coprice) {
		this.coprice = coprice;
	}
	public String getCoupload_date() {
		return coupload_date;
	}
	public void setCoupload_date(String coupload_date) {
		this.coupload_date = coupload_date;
	}
	public int getTnum() {
		return tnum;
	}
	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getT_image() {
		return t_image;
	}
	public void setT_image(String t_image) {
		this.t_image = t_image;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getVisa() {
		return visa;
	}
	public void setVisa(String visa) {
		this.visa = visa;
	}
	public String getTterm() {
		return tterm;
	}
	public void setTterm(String tterm) {
		this.tterm = tterm;
	}
	public String getTwageratio() {
		return twageratio;
	}
	public void setTwageratio(String twageratio) {
		this.twageratio = twageratio;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	
	
}
